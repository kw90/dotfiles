# LastPass vault search Albert extension

Command to execute `lp `... For example:

`lp gmail` and press Enter to add the password to your clipboard OR keep holding the `ALT` key to get more options

## Instalation
Add folder to:
> /usr/share/albert/org.albert.extension.python/modules

For example:
```sh
ln -s $(pwd)/Downloads/lastpass-albert-extension/  /usr/share/albert/org.albert.extension.python/modules/
```

Activate the extension in the albert settings extension menu